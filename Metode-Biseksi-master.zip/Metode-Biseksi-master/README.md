# Metode Biseksi
 Perhitungan Metode Biseksi berbasis Web menggunakan PHP dan JavaScript

# Fungsi :
 f(x) = x-1-e-x
 
# Screenshot

![biseksi](https://user-images.githubusercontent.com/33270746/70012531-3324e880-15a7-11ea-98c7-9a818a39ce50.png)

